using UnityEngine;
using Unity.Robotics.ROSTCPConnector;
using RosMessageTypes.Geometry;
using RosMessageTypes.Sensor;

public class CmdVelTestPublisher : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    ROSConnection ros;
    public string topicName = "/cmd_vel";
    
    void Start()
    {
        ros = ROSConnection.GetOrCreateInstance();
        ros.RegisterPublisher<TwistMsg>(topicName);
        Debug.Log("CmdVel Publisher registered");
    }

    // Update is called once per frame
    void Update()
    {
        TwistMsg msg = new TwistMsg();
        msg.linear.x = 0.1;
        msg.angular.z = 0.1;
        
        ros.Publish(topicName, msg);
        Debug.Log("Publishing in /CmdVel");
    }
}
