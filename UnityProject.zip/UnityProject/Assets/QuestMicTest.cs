using UnityEngine;
using UnityEngine.XR;
using TMPro;

public class QuestMicTest : MonoBehaviour
{
    public TextMeshProUGUI debugText;
    
    private AudioClip micClip;
    private bool isRecording = false;
    private int sampleWindow = 128;
    
    void Start()
    {
    	debugText.text = "Ready...";
    	Debug.Log("Script Iniciado");
    }
    
    void Update()
    {
    	CheckControllerInput();
    	
    	if (isRecording)
    	{
    		float level = GetMicLevel();
    		Debug.Log("MIC LEVEL: "+ level);
    		
    		if (level > 0.01f)
    		{
    			Debug.Log("VOICE DETECTED");
    		}
    		else
    		{
    			Debug.Log("SILENCE");
    		}
    	}
    }
    
    void CheckControllerInput()
    {
    	InputDevice rightHand = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
    	
    	bool triggerPressed;
    	
    	if (rightHand.TryGetFeatureValue(CommonUsages.triggerButton, out triggerPressed))
    	{
    		if (triggerPressed && !isRecording)
    		{
    			Debug.Log("PRESSEEEEEEED");
    			StartRecording();
    		}
    		
    		if (!triggerPressed && isRecording)
    		{
    			StopRecording();
    		}
    	}
    }
    
    void StartRecording()
    {
    	Debug.Log("START RECORDING");
    	
    	micClip = Microphone.Start(null, true, 10, 16000);
    	isRecording = true;
    }
    
    
    void StopRecording()
    {
    	Debug.Log("STOP RECORDING");
    	
    	Microphone.End(null);
    	isRecording = false;
    }
    
    float GetMicLevel()
    {
    	if (micClip == null) return 0;
    	
    	int micPosition = Microphone.GetPosition(null) - sampleWindow + 1;
    	if (micPosition < 0) return 0;
    	
    	float[] samples = new float[sampleWindow];
    	micClip.GetData(samples, micPosition);
    	float max = 0;
    	for (int i = 0; i < sampleWindow; i++)
    	{
    		float abs = Mathf.Abs(samples[i]);
    		if(abs > max)
    		{
    			max = abs;
    		}
      	}
    	
    	return max;
    }    
}
