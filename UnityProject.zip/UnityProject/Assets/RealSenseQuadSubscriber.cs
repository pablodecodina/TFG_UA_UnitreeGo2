using UnityEngine;
using Unity.Robotics.ROSTCPConnector;
using RosMessageTypes.Sensor;

public class RealSenseQuadSubscriber : MonoBehaviour
{
    public Renderer targetRenderer;
    public string topicName = "/camera/color/image_raw/compressed";

    private ROSConnection ros;
    private Texture2D texture;
    private byte[] latestImageData;
    private bool newImageReceived = false;

    void Start()
    {
        texture = new Texture2D(2, 2);
        targetRenderer.material.mainTexture = texture;

        ros = ROSConnection.GetOrCreateInstance();
        ros.Subscribe<CompressedImageMsg>(topicName, ImageCallback);

        Debug.Log("Subscribed to: " + topicName);
    }

    void ImageCallback(CompressedImageMsg msg)
    {
        latestImageData = msg.data;
        newImageReceived = true;
    }

    void Update()
    {
        if (newImageReceived)
        {
            texture.LoadImage(latestImageData);
            newImageReceived = false;
        }
    }
}
