Shader "Custom/DepthStereoCorrected"
{
    Properties
    {
        _MainTex ("Color Texture", 2D) = "white" {}
        _DepthTex ("Depth Texture", 2D) = "white" {}
        _IPD ("Eye Distance", Float) = 0.064
        _DepthScale ("Depth Scale", Float) = 0.001
        _ParallaxStrength ("Parallax Strength", Float) = 0.03
        _MaxShift ("Max Shift", Float) = 0.02
    }

    SubShader
    {
        Tags { "RenderType"="Opaque" }
        LOD 100

        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_instancing
            #include "UnityCG.cginc"

            sampler2D _MainTex;
            sampler2D _DepthTex;

            float _IPD;
            float _DepthScale;
            float _ParallaxStrength;
            float _MaxShift;

            struct appdata
            {
                float4 vertex : POSITION;
                float2 uv : TEXCOORD0;
            };

            struct v2f
            {
                float2 uv : TEXCOORD0;
                float4 vertex : SV_POSITION;
                UNITY_VERTEX_OUTPUT_STEREO
            };

            v2f vert (appdata v)
            {
                v2f o;
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
                o.vertex = UnityObjectToClipPos(v.vertex);
                o.uv = v.uv;
                return o;
            }

            fixed4 frag (v2f i) : SV_Target
            {
                float depthRaw = tex2D(_DepthTex, i.uv).r;

                // Convertimos depth a metros
                float depthMeters = depthRaw * _DepthScale;

                // Evitar divisiones por cero
                depthMeters = max(depthMeters, 0.1);

                // Calcular desplazamiento inversamente proporcional a depth
                float shift = (_IPD * _ParallaxStrength) / depthMeters;

                // Limitar desplazamiento máximo
                shift = clamp(shift, -_MaxShift, _MaxShift);

                #if defined(UNITY_SINGLE_PASS_STEREO)
                    if (unity_StereoEyeIndex == 0)
                        i.uv.x -= shift;
                    else
                        i.uv.x += shift;
                #endif

                return tex2D(_MainTex, i.uv);
            }
            ENDCG
        }
    }
}
